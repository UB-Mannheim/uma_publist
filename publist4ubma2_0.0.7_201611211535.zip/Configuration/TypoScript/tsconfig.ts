tx_publist4ubma2.templateLayouts.0 = Default (All)
tx_publist4ubma2.templateLayouts.1 = Debug Table
tx_publist4ubma2.templateLayouts.2 = DWS - RDFA - Schema
tx_publist4ubma2.templateLayouts.3 = BIB with Coins
tx_publist4ubma2.templateLayouts.4 = BWL - APA

